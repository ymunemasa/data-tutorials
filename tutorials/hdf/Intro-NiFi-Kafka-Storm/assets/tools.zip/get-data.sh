#!/bin/sh

curl -s localhost:9095 |jq .