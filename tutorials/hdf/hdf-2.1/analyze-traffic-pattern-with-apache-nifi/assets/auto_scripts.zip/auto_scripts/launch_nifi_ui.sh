#!/bin/bash
./docker-scripts/docker_sandbox_hdf.sh
#Access NiFi HTML UI via Mac CLI
echo "Launch NiFi HTML UI..."
open http://sandbox.hortonworks.com:19090/nifi/
